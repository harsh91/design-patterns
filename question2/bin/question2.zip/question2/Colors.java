package question2;

public interface Colors {
 
	public void fill();
	
}
