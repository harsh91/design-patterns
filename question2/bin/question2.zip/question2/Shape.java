package question2;

// File   : gui-lowlevel/paintdemo/Shape.java
// Purpose: Defines the shapes that can be drawn.
// Author : Fred Swartz - October 12, 2006 - Placed in public domain.


/////////////////////////////////////////////////////////////////// Shape
public enum Shape { RECTANGLE, OVAL, LINE }