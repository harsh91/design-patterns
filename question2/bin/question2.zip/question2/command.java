package question2;

public interface command {

	public void executeUndo();
	public void executeRedo();
}


